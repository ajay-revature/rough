<?php
get_header(); ?>

<?php get_template_part( 'template-parts/content', get_post_format() ); ?>

<?php get_footer(); ?>

window.sr = ScrollReveal({duration: 1000, distance:'30px'});
sr.reveal('.icon-holder-left', {origin:'left'});
sr.reveal('.icon-holder-right', {origin:'right'});
sr.reveal('.icon-content-right', {origin:'right'});
sr.reveal('.icon-content-left', {origin:'left'});
sr.reveal('.wwd-content', {origin:'bottom'});
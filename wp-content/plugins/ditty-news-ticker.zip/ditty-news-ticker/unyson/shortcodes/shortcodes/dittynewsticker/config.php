<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Ditty News Ticker', 'ditty-news-ticker' ),
	'description' => __( 'Add a News Ticker', 'ditty-news-ticker' ),
	'tab'         => __( 'Content Elements', 'ditty-news-ticker' ),
	'icon' 				=> 'mtphr-dnt-icon-dittynewsticker'
);